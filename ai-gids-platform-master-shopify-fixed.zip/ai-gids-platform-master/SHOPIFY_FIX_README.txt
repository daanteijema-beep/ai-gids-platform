Wat is aangepast:
- app/page.tsx vangt nu Shopify install requests met ?shop=... op en redirect naar /api/auth/shopify
- app/api/auth/shopify/route.ts gebruikt nu dynamisch de shop uit de request in plaats van een vaste SHOPIFY_STORE_URL
- app/api/auth/shopify/callback/route.ts valideert nu state en hmac voordat de token exchange gebeurt

Nog instellen in Shopify:
- App URL: https://vakwebtwente.vercel.app
- Redirect URL / Allowed redirection URL:
  https://vakwebtwente.vercel.app/api/auth/shopify/callback

Benodigde env vars:
- SHOPIFY_CLIENT_ID
- SHOPIFY_CLIENT_SECRET
- NEXT_PUBLIC_APP_URL=https://vakwebtwente.vercel.app

Opmerking:
Dit is een goede minimale OAuth-fix voor jouw huidige app.
Voor een volledig production-grade embedded Shopify app ontbreken nog o.a. sessiebeheer, tokenopslag per shop en App Bridge/embedded rendering.
