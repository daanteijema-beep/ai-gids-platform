import { NextRequest, NextResponse } from 'next/server'
import crypto from 'crypto'

function isValidShopDomain(shop: string) {
  return /^[a-zA-Z0-9][a-zA-Z0-9-]*\.myshopify\.com$/.test(shop)
}

export async function GET(req: NextRequest) {
  const clientId = process.env.SHOPIFY_CLIENT_ID
  const appUrl = process.env.NEXT_PUBLIC_APP_URL
  const shop = req.nextUrl.searchParams.get('shop')

  if (!clientId || !appUrl) {
    return NextResponse.json(
      { error: 'Missing SHOPIFY_CLIENT_ID or NEXT_PUBLIC_APP_URL' },
      { status: 500 }
    )
  }

  if (!shop || !isValidShopDomain(shop)) {
    return NextResponse.json({ error: 'Invalid or missing shop parameter' }, { status: 400 })
  }

  const redirectUri = `${appUrl}/api/auth/shopify/callback`
  const scopes = 'read_products,write_products,read_orders,read_inventory,write_inventory'
  const state = crypto.randomBytes(16).toString('hex')

  const authUrl = new URL(`https://${shop}/admin/oauth/authorize`)
  authUrl.searchParams.set('client_id', clientId)
  authUrl.searchParams.set('scope', scopes)
  authUrl.searchParams.set('redirect_uri', redirectUri)
  authUrl.searchParams.set('state', state)

  const response = NextResponse.redirect(authUrl.toString())
  response.cookies.set('shopify_oauth_state', state, {
    httpOnly: true,
    sameSite: 'lax',
    secure: true,
    path: '/',
    maxAge: 60 * 10,
  })

  return response
}
