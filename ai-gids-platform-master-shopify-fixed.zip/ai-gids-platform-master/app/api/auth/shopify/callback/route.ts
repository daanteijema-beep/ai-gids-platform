import { NextRequest, NextResponse } from 'next/server'
import crypto from 'crypto'

function isValidShopDomain(shop: string) {
  return /^[a-zA-Z0-9][a-zA-Z0-9-]*\.myshopify\.com$/.test(shop)
}

function verifyHmac(searchParams: URLSearchParams, secret: string) {
  const entries: string[] = []
  searchParams.forEach((value, key) => {
    if (key !== 'hmac' && key !== 'signature') {
      entries.push(`${key}=${value}`)
    }
  })
  const message = entries.sort().join('&')
  const generated = crypto.createHmac('sha256', secret).update(message).digest('hex')
  const received = searchParams.get('hmac') || ''
  if (!received) return false
  try:
    return crypto.timingSafeEqual(Buffer.from(generated, 'utf8'), Buffer.from(received, 'utf8'))
  } catch {
    return false
  }
}

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url)
  const code = searchParams.get('code')
  const shop = searchParams.get('shop')
  const state = searchParams.get('state')
  const cookieState = req.cookies.get('shopify_oauth_state')?.value
  const clientId = process.env.SHOPIFY_CLIENT_ID
  const clientSecret = process.env.SHOPIFY_CLIENT_SECRET

  if (!clientId || !clientSecret) {
    return NextResponse.json({ error: 'Missing Shopify app credentials' }, { status: 500 })
  }

  if (!code || !shop || !isValidShopDomain(shop)) {
    return NextResponse.json({ error: 'Missing or invalid code/shop' }, { status: 400 })
  }

  if (!state || !cookieState || state !== cookieState) {
    return NextResponse.json({ error: 'Invalid OAuth state' }, { status: 400 })
  }

  const hmacOk = verifyHmac(searchParams, clientSecret)
  if (!hmacOk) {
    return NextResponse.json({ error: 'Invalid HMAC' }, { status: 400 })
  }

  try {
    const res = await fetch(`https://${shop}/admin/oauth/access_token`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        client_id: clientId,
        client_secret: clientSecret,
        code,
      }),
    })

    const data = await res.json().catch(() => null)

    if (!res.ok || !data?.access_token) {
      return NextResponse.json(
        { error: 'Token exchange failed', details: data || `HTTP ${res.status}` },
        { status: 400 }
      )
    }

    const html = `
      <html>
        <body style="font-family:sans-serif;padding:40px;max-width:720px">
          <h2>✅ Shopify gekoppeld</h2>
          <p>Zet deze waarde in je environment variables:</p>
          <code style="background:#f3f4f6;padding:12px;display:block;border-radius:8px;word-break:break-all;font-size:13px">
            SHOPIFY_ACCESS_TOKEN=${data.access_token}
          </code>
          <p style="margin-top:16px">Shop: <strong>${shop}</strong></p>
          <p>Redirect URL in Shopify moet zijn: <strong>${process.env.NEXT_PUBLIC_APP_URL}/api/auth/shopify/callback</strong></p>
        </body>
      </html>
    `
    const response = new NextResponse(html, { headers: { 'Content-Type': 'text/html' } })
    response.cookies.set('shopify_oauth_state', '', { path: '/', maxAge: 0 })
    return response
  } catch (err) {
    return NextResponse.json(
      { error: 'Unexpected callback error', details: String(err) },
      { status: 500 }
    )
  }
}
